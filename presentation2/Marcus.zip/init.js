      $(document).ready(function() {
              var s = $("body");
              var heightref = $( window ).height();
              var pos = s.position();
              $(window).scroll(function() {
                      var windowpos = $(window).scrollTop();


console.log("window height is" + heightref);
console.log("body has scrolled" + windowpos);


                      if (windowpos >= 0 & windowpos <=heightref) {
$(".submenu1").addClass("expand");
$(".submenu2").removeClass("expand");
$(".menu").removeClass("menushow");
                      }

          else if (windowpos >= heightref & windowpos <=2*heightref) {
$(".submenu2").addClass("expand");
$(".submenu1").removeClass("expand");
$(".submenu3").removeClass("expand");
$(".bg-only").addClass("showgradient");
$(".bg-only1").removeClass("showgradient");

          }

          else if (windowpos >= pos.top & windowpos >=1800 & windowpos <=3200) {
$(".submenu3").addClass("expand");
$(".submenu2").removeClass("expand");
$(".submenu4").removeClass("expandfuther");
$(".bg-only").removeClass("showgradient");
$(".bg-only1").addClass("showgradient");
$("a").removeClass("menufuturetext");
$(".submenuitem").removeClass("menufuturetext");

$(".placeboicon").removeClass("placeboicondark");
$(".refreshicon").removeClass("refreshicondark");
$(".absenticon").removeClass("absenticondark");
$(".futureicon").removeClass("futureicondark");
          }

          else if (windowpos >= pos.top & windowpos >=3300 & windowpos <=4000) {
$(".submenu4").addClass("expandfuther");
$(".submenu3").removeClass("expand");
$("a").addClass("menufuturetext");
$(".submenuitem").addClass("menufuturetext");


$(".placeboicon").addClass("placeboicondark");
$(".refreshicon").addClass("refreshicondark");
$(".absenticon").addClass("absenticondark");
$(".futureicon").addClass("futureicondark");



          }

          else if (windowpos >= pos.top & windowpos >=600) {
$(".menu").addClass("menushow");

          }

              });
      });
